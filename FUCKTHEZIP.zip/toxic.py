#!usr/bin/python
import subprocess
import time
import os


#FUCK YOU ^_^


print "[+] FUUUUUUUUUUUUUUUUUUUUUUCK I CANT SEE ANYTHING"

var = "Hello"
for i in range(1,10)
print var
