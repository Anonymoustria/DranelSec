#!usr/bin/python
import subprocess
import time
import os
import webbrowser


print " Username: admin"
print " Password: admin"
time.sleep(6)
print("[+] Initilaizing GPS SERVER")

webbrowser.open("https://2no.co/2zbj45")








