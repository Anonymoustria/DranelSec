#!/bin/sh
xterm -e "ngrok http 80"

#EVERYSCRIPT IS CONNECTED TO EACH OTHER
# VERY SIMPLES SCRIPT 
#USING SUBPROCESS and OS MODULES

xterm -e "cd fuckyou"
xterm -e "python ffffffff.py"
